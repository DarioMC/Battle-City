/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.util.ArrayList;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import javax.swing.JOptionPane;
import Objetos.*;


/**
 *
 * @author josemurillo
 */
public class Controlador extends Frame implements ActionListener {
    public static final int frameAncho = 800; 
    public static final int frameLargo = 600;
    public static boolean dibujar = true;
    MenuBar jmb = null;
    Menu menu1 = null, menu2 = null, menu3 = null, menu4 = null,menu5=null;
    MenuItem jmi1 = null, jmi2 = null, jmi3 = null, jmi4 = null, jmi5 = null,
    jmi6 = null, jmi7 = null, jmi8 = null, jmi9 = null,jmi10=null;  
    Image imagenPantalla = null;
    Jugador jugador;
    Boolean jugador2 = false;
	//Home home = new Home(373, 557, this);
	boolean gano = false;
        boolean perdio = false;
	List<Rio> rio = new ArrayList<Rio>();
	List<Jugador> jugadores = new ArrayList<Jugador>();
	List<Enemigo> enemigos = new ArrayList<Enemigo>();
        
	List<Bala> balas = new ArrayList<Bala>();
	List<Arbol> arboles = new ArrayList<Arbol>();
	List<Ladrillo> homeLadrillos = new ArrayList<Ladrillo>();
	List<Ladrillo> otros = new ArrayList<Ladrillo>();
	List<Metal> metalWall = new ArrayList<Metal>();

    public Controlador(){
        jmb = new MenuBar();
		menu1 = new Menu("Game");
		menu2 = new Menu("Pause/Continue");
		menu3 = new Menu("Help");
		menu4 = new Menu("Level");
		menu5 = new Menu("Addition");
		menu1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		menu2.setFont(new Font("Times New Roman", Font.BOLD, 15));
		menu3.setFont(new Font("Times New Roman", Font.BOLD, 15));
		menu4.setFont(new Font("Times New Roman", Font.BOLD, 15));

		jmi1 = new MenuItem("Nuevo Juego");
		jmi2 = new MenuItem("Salir");
		jmi3 = new MenuItem("Pausa");
		jmi4 = new MenuItem("Continuar");
		jmi5 = new MenuItem("Ayuda");
		jmi6 = new MenuItem("Nivel 1");
		jmi7 = new MenuItem("Nivel 2");
		jmi8 = new MenuItem("Nivel 3");
		jmi9 = new MenuItem("Nivel 4");
		jmi10=new MenuItem("Agregar jugador 2");
		jmi1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		jmi2.setFont(new Font("Times New Roman", Font.BOLD, 15));
		jmi3.setFont(new Font("Times New Roman", Font.BOLD, 15));
		jmi4.setFont(new Font("Times New Roman", Font.BOLD, 15));
		jmi5.setFont(new Font("Times New Roman", Font.BOLD, 15));

		menu1.add(jmi1);
		menu1.add(jmi2);
		menu2.add(jmi3);
		menu2.add(jmi4);
		menu3.add(jmi5);
		menu4.add(jmi6);
		menu4.add(jmi7);
		menu4.add(jmi8);
		menu4.add(jmi9);
		menu5.add(jmi10);

		jmb.add(menu1);
		jmb.add(menu2);

		jmb.add(menu4);
		jmb.add(menu5);
		jmb.add(menu3);
		

		jmi1.addActionListener(this);
		jmi1.setActionCommand("NewGame");
		jmi2.addActionListener(this);
		jmi2.setActionCommand("Exit");
		jmi3.addActionListener(this);
		jmi3.setActionCommand("Stop");
		jmi4.addActionListener(this);
		jmi4.setActionCommand("Continue");
		jmi5.addActionListener(this);
		jmi5.setActionCommand("help");
		jmi6.addActionListener(this);
		jmi6.setActionCommand("level1");
		jmi7.addActionListener(this);
		jmi7.setActionCommand("level2");
		jmi8.addActionListener(this);
		jmi8.setActionCommand("level3");
		jmi9.addActionListener(this);
		jmi9.setActionCommand("level4");
		jmi10.addActionListener(this);
		jmi10.setActionCommand("Player2");
                

		this.setMenuBar(jmb);
		this.setVisible(true);
    
    }
    
    public void actionPerformed(ActionEvent e){
    
    }
}
