/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Objetos;
import Controlador.Controlador;
import java.awt.Toolkit;

/**
 *
 * @author josemurillo
 */
public class Jugador extends Tanque{
    private Controlador c;
    
    public Jugador(int x, int y, boolean bueno, int tipoJugador, String direccion, Controlador pC){
        super();
        this.x = x;
        this.y = y;
        this.tipoTanque = bueno;
        this.vida = 250;
        this.largo = 35;
        this.ancho = 35;
        this.velocidad = 6;
        this.tk = Toolkit.getDefaultToolkit();
        this.c = pC;
        
        switch (direccion){
            case "W":
                this.imagen = this.imagenes[1];
                break;
            case "A":
                this.imagen = this.imagenes[2];
                break;
            case "S":
                this.imagen = this.imagenes[0];
                break;
            case "D":
                this.imagen = this.imagenes[3];
        }
    }
      
    public void mover(String direccion){
                
		

		switch (direccion) {  
		case "A":
			x -= velocidad;
			break;
		case "W":
			y -= velocidad;
			break;
		case "D":
			x += velocidad;
			break;
		case "S":
			y += velocidad;
			break;
		}
		
     
     }
    
/*
    if (x < 0)d
			x = 0;
		if (y < 40)     
			y = 40;
		if (x + Tank.width > TankClient.Fram_width)  
			x = TankClient.Fram_width - Tank.width;
		if (y + Tank.length > TankClient.Fram_length)
			y = TankClient.Fram_length - Tank.length;*/
        
     public void colocar(){
         
     }   
}
