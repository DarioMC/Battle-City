/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Objetos;
import java.awt.*;
import java.awt.event.*;
import java.util.*;


/**
 *
 * @author josemurillo
 */
public abstract class Tanque extends Objeto implements Movible{
    protected boolean tipoTanque;
    protected int velocidad;
    protected Image[] imagenes = {
            tk.getImage ("Images/tankD.gif"),
			tk.getImage("Imagenes/tankU.gif"),
			tk.getImage("Imagenes/tankL.gif"),
			tk.getImage("Imagenes/tankR.gif"), 
			tk.getImage("Imagenes/HtankD.gif"), 
			tk.getImage("Imagenes/HtankU.gif"), 
			tk.getImage("Imagenes/HtankL.gif"),
			tk.getImage("Imagenes/HtankR.gif"), 
			tk.getImage("Imagenes/HtankD2.gif"),
			tk.getImage("Imagenes/HtankU2.gif"),
			tk.getImage("Imagenes/HtankL2.gif"),
			tk.getImage("Imagenes/HtankR2.gif"),
			};
    
    public Tanque(){
        super();
    }
    
    @Override
    public void mover(){
    
    }
    
}
